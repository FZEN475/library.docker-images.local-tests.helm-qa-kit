# BEGSCRIPT
set -e

function log_info() {
    echo -e "[\e[1;94mINFO\e[0m] $*"
}

function log_warn() {
    echo -e "[\e[1;93mWARN\e[0m] $*"
}

function log_error() {
    echo -e "[\e[1;91mERROR\e[0m] $*"
}

function fail() {
  log_error "$*"
  exit 1
}

function assert_defined() {
  if [[ -z "$1" ]]; then
    log_error "$2"
    exit 1
  fi
}

function install_tool() {
  tools="$*"

  # Определяем ОС
  if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_ID="$ID"
  else
    OS_ID=""
  fi

  case "$OS_ID" in
    ubuntu|debian)
      if command -v apt-get >/dev/null 2>&1; then
          apt-get update -qq
          apt-get install -y -qq $tools
      else
          echo "⚠️ apt-get не найден, установка пропущена"
      fi
      ;;

    alpine)
      if command -v apk >/dev/null 2>&1; then
          apk add $tools
      else
          echo "⚠️ apk не найден, установка пропущена"
      fi
      ;;

    centos|rhel|fedora|rocky|alma)
      if command -v dnf >/dev/null 2>&1; then
          dnf install -y $tools
      elif command -v yum >/dev/null 2>&1; then
          yum install -y $tools
      else
          echo "⚠️ dnf/yum не найден, установка пропущена"
      fi
      ;;

    *)
        echo "⚠️ Неизвестная ОС ($OS_ID) — установка пропущена"
        ;;
  esac
}

function register_ca() {
  crt_file="$1"

  if [ ! -f "$crt_file" ]; then
    log_warn "⚠️ Файл $crt_file не найден"
    return 0
  fi

  # Определяем ОС
  if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_ID="$ID"
    OS_NAME="$NAME"
  else
    log_warn "⚠️ Не удалось определить операционную систему"
    return 0
  fi

  log_info "ℹ️ Обнаружена ОС: $OS_NAME ($OS_ID)"

  case "$OS_ID" in
    ubuntu|debian)
      cp "$crt_file" /usr/local/share/ca-certificates/ 2>/dev/null || log_warn "⚠️ Не удалось скопировать файл"
      if command -v update-ca-certificates >/dev/null 2>&1; then
          update-ca-certificates 2>/dev/null || log_warn "⚠️ Ошибка при обновлении сертификатов"
      else
          log_warn "⚠️ Пакет ca-certificates не найден, обновление сертификатов пропущено"
      fi
      log_info "✅ Сертификат зарегистрирован (файл скопирован)"
      ;;

    alpine)
      cp "$crt_file" /usr/local/share/ca-certificates/ 2>/dev/null || log_warn "⚠️ Не удалось скопировать файл"
      if command -v update-ca-certificates >/dev/null 2>&1; then
          update-ca-certificates 2>/dev/null || log_warn "⚠️ Ошибка при обновлении сертификатов"
      else
          log_warn "⚠️ Пакет ca-certificates не найден, обновление сертификатов пропущено"
      fi
      log_info "✅ Сертификат зарегистрирован (файл скопирован)"
      ;;

    centos|rhel|fedora|rocky|alma)
      cp "$crt_file" /etc/pki/ca-trust/source/anchors/ 2>/dev/null || log_warn "⚠️ Не удалось скопировать файл"
      if command -v update-ca-trust >/dev/null 2>&1; then
          update-ca-trust extract 2>/dev/null || log_warn "⚠️ Ошибка при обновлении сертификатов"
      else
          log_warn "⚠️ Пакет ca-certificates не найден, обновление сертификатов пропущено"
      fi
      log_info "✅ Сертификат зарегистрирован (файл скопирован)"
      ;;

    *)
      log_warn "⚠️ Неизвестная ОС ($OS_ID) — регистрация сертификата пропущена"
      return 0
      ;;
  esac
}

create_kubeconfig() {
  SA_DIR="/run/secrets/kubernetes.io/serviceaccount"

  # Проверка наличия serviceaccount
  [ -d "$SA_DIR" ] || return 0
  [ -f "$SA_DIR/token" ] || return 0
  [ -f "$SA_DIR/ca.crt" ] || return 0

  # Переменные Kubernetes
  KUBE_HOST=${KUBERNETES_SERVICE_HOST:-}
  KUBE_PORT=${KUBERNETES_SERVICE_PORT:-}
  [ -n "$KUBE_HOST" ] || return 0
  [ -n "$KUBE_PORT" ] || return 0

  TOKEN=$(cat "$SA_DIR/token")
  NAMESPACE=$(cat "$SA_DIR/namespace" 2>/dev/null || echo default)

  # Директория kubeconfig
  KUBE_DIR="$HOME/.kube"
  KUBE_CONFIG="$KUBE_DIR/config"

  mkdir -p "$KUBE_DIR"
  chmod 700 "$KUBE_DIR"

  cat > "$KUBE_CONFIG" <<EOF
apiVersion: v1
kind: Config
clusters:
- name: kube-cluster
  cluster:
    server: https://${KUBE_HOST}:${KUBE_PORT}
    certificate-authority: ${SA_DIR}/ca.crt
users:
- name: default
  user:
    token: ${TOKEN}
contexts:
- name: default
  context:
    cluster: kube-cluster
    user: default
    namespace: ${NAMESPACE}
current-context: default
EOF
  chmod 600 "$KUBE_CONFIG"
}