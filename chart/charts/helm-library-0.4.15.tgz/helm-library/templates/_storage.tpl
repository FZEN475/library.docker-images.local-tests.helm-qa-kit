{{/*
Get list from multiple list source with concat for volumeMounts value.
Variables [list]:
  - name - pvc and volume name
  - vars - List of source dict
*/}}

{{- define "pvc.get_volume_mount" -}}
{{-   $list := (list) -}}
{{-   range $key := index . "vars" -}}
{{-     $list = concat (default (list) $list) (default (list) $key) | uniq | compact -}}
{{-   end -}}
{{-   if $list -}}
{{-     range $vm := $list -}}
{{-       if and (index $vm "name") (index $vm "create")  (eq ((index $vm "name") | kindOf) "string" ) }}
- name: {{ (index $vm "name") }}
  mountPath: {{ (default (printf "%s%s" ("/tmp/") (index $vm "name") ) (index $vm "mountPath")) }}
  readOnly: {{ (default (true) (index $vm "readOnly")) }}
{{-       end -}}
{{-     end -}}
{{-   end -}}
{{- end -}}

{{/*
Get list from multiple list source with concat for volumeMounts value.
Variables [list]:
  - name - pvc and volume name (pvc name - .Release.Namespace-.Release.Name-name-pvc)
  - vars - List of source dict
*/}}

{{- define "pvc.get_volumes" -}}
{{-   $list := (list) -}}
{{-   range $key := index . "vars" -}}
{{-     $list = concat (default (list) $list) (default (list) $key) | uniq | compact -}}
{{-   end -}}
{{-   if $list -}}
{{-     range $v := $list -}}
{{-       if and (index $v "name") (eq ((index $v "name") | kindOf) "string" ) }}
- name: {{ (index $v "name") }}
  persistentVolumeClaim:
    claimName: {{ (index $ "global").Release.Namespace }}-{{ (index $ "global").Release.Name }}-{{ (index $v "name") }}-pvc
{{-       end -}}
{{-     end -}}
{{-   end -}}
{{- end -}}