
{{/*
Get ports.
Variables [list]:
  - ports - list of port lists
  - service - output service format
Min format
ports:
  - name: test1
    port: 21
    protocol: TCP
  - name: test2
    port: 22
    protocol: TCP
*/}}

{{- define "net.get_ports" -}}
{{-   $list := (list) -}}
{{-    if index . "ports" }}
{{-     range $key := index . "ports" -}}
{{-        $list = concat (default (list) $list) (default (list) $key) | uniq | compact -}}
{{-     end -}}
{{-   end -}}
{{-   if $list -}}
{{-     range $port := $list }}
- name: {{ $port.name }}
{{-   if (index $ "service") }}
  containerPort: {{ $port.port }}
  targetPort: {{ $port.name }}
{{-   else }}
  port: {{ $port.port }}
{{-   end }}
  protocol: {{ $port.protocol }}
{{-     end -}}
{{-   end -}}
{{- end -}}

{{/*
Get ports from multiple source (for service).
Variables [list]:
  - containers - list of containers lists
  - container - output format container/service (bool)
Min format
containers1:
  - name: c1
    ports:
      - name: test1
        port: 21
        protocol: TCP
    extraPorts:
      - name: extra1
        port: 9991
        protocol: TCP
containers2:
  - name: c2
    ports:
      - name: test2
        port: 22
        protocol: TCP
*/}}

{{- define "net.get_all_ports" -}}
{{-   $portList := (list) -}}
{{-   $extraPortList := (list) -}}
{{-   if index . "containers" -}}
{{-     range $containers := index . "containers" }}
{{-       range $container := $containers }}
{{-          if index $container "ports" }}
{{-            $portList = concat (default (list) $portList) (default (list) (index $container "ports")) | uniq | compact -}}
{{-         end }}
{{-         if index . "extraPorts" -}}
{{-            $extraPortList = concat (default (list) $extraPortList) (default (list) (index $container "extraPorts")) | uniq | compact -}}
{{-         end -}}
{{-       end }}
{{-     end }}
{{-   end -}}
{{-   if or $portList $extraPortList }}
ports:
  {{- template "net.get_ports" (dict  "ports" (list  $portList $extraPortList) "container"  (index . "container"))  }}
{{-   end }}
{{- end -}}







{{- define "net.service.get_ip" -}}
{{-   $tupe :=  (default ("ClusterIP") ( index $ "tupe" | first )) -}}
{{-   if and  (index $ "tupe") (eq $tupe "ClusterIP") -}}
  clusterIP: {{ default ("None") ((index $ "vars") | first | quote) -}}
{{-   else if and (index $ "tupe") (eq $tupe "LoadBalancer") -}}
  loadBalancerIP: {{ default ("None") ((index $ "vars") | first | quote) -}}
{{-   end -}}
{{- end -}}




{{/*
Get value from multiple source with list of acceptable values.
Variables [str]:
  - containers - list of containers lists
  - context - global context
Min format
containers1:
  - name: c1
    ports:
      - name: test1
        port: 21
        protocol: TCP
        ingress:
          path: /
          pathType: Prefix
    extraPorts:
      - name: extra1
        port: 9991
        protocol: TCP
        ingress:
          path: /
          pathType: Prefix
containers2:
  - name: c2
    ports:
      - name: test2
        port: 22
        protocol: TCP
        ingress:
          path: /
          pathType: Prefix
*/}}

{{- define "net.ingress.get_all_ports" -}}
{{-   $containerList := (list) -}}
{{-   if index . "containers" -}}
{{-     range $containers := index . "containers" -}}
{{-       range $container := $containers -}}
{{-         if index $container "ports" }}
{{-   $defaultDomain := (printf "%s.svc" (index $ "context" ).Release.Namespace ) }}
{{-   $host := (printf "%s.%s" ($container.name ) (default ($defaultDomain) (index $ "domain"))) }}
- host: {{ $host }}
  http:
    paths:
{{-           range $port := index $container "ports" }}
      - backend:
        path: {{ default ("/") $port.ingress.path | quote }}
        pathType: {{ default ("Prefix") $port.ingress.pathType }}
        service:
          name: {{ (index $ "context").Release.Name }}
          port:
            number: {{ $port.port }}
{{-           end -}}
{{-            range $port := index $container "extraPorts" }}
      - backend:
        path: {{ default ("/") $port.ingress.path | quote }}
        pathType: {{ default ("Prefix") $port.ingress.pathType }}
        service:
          name: {{ (index $ "context").Release.Name }}
          port:
            number: {{ $port.port }}
{{-           end -}}
{{-         end -}}
{{-       end -}}
{{-     end -}}
{{-   end -}}
{{- end -}}








{{/*
Get value from multiple source with list of acceptable values.
Variables [str]:
  - tls - tls data
  - containers - list of containers lists
  - certificate - certificate format
  - context - global context
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Min format  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
containers1:
  - name: c1
    ports:
      - name: test1
        port: 21
        protocol: TCP
        ingress:
          path: /
          pathType: Prefix
    extraPorts:
      - name: extra1
        port: 9991
        protocol: TCP
        ingress:
          path: /
          pathType: Prefix
containers2:
  - name: c2
    ports:
      - name: test2
        port: 22
        protocol: TCP
        ingress:
          path: /
          pathType: Prefix
*/}}

{{- define "net.get_tls_data" -}}
{{-   $dnsList := (list) -}}
{{-   if index . "containers" -}}
{{-     range $containers := index . "containers" }}
{{-       range $container := $containers }}
{{-         $defaultDomain := (printf "%s.svc" (index $ "context" ).Release.Namespace ) }}
{{-         $dns := (printf "%s.%s" ($container.name ) (default ($defaultDomain) (index (index $ "tls" ) "domain"))) }}
{{-         $tmpList := (list $dns) }}
{{-         $dnsList = concat (default (list) $dnsList) (default (list) $tmpList) }}
{{-       end }}
{{-     end }}
{{-   end -}}
{{-   $dnsList = concat (default (list) $dnsList) (default (list) (index (index $ "tls" ) "extraDNSNames")) }}
{{-   if $dnsList  }}
{{-     if index . "certificate"  }}
dnsNames:
{{- $dnsList | toYaml | nindent 2 }}
{{-     else }}
- hosts:
{{- $dnsList | toYaml | nindent 2 }}
  secretName: {{ default (printf "%s%s%s" ("cm-") ((index . "context").Release.Name) "-tls" ) (index (index $ "tls" ) "secretName") }}
{{-     end }}
{{-   end }}
{{- end -}}















