
{{/* _utility.sh.tpl */}}
{{- define "utility.common.sh" -}}
{{ .Files.Get "files/common.sh" | nindent 0 }}
{{- end -}}
